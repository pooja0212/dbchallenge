package com.db.awmd.challenge;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.exception.DuplicateAccountIdException;
import com.db.awmd.challenge.service.AccountsService;

@SpringBootTest
class DbchallengeApplicationTests {

	  @Autowired
	  private AccountsService accountsService;

	  @Test
	  public void addAccount() throws Exception {
	    Account account = new Account("Id-123");
	    account.setBalance(new BigDecimal(1000));
	    this.accountsService.createAccount(account);

	    assertThat(this.accountsService.getAccount("Id-123")).isEqualTo(account);
	  }
	  
	  @Test
	  public void addAccount_failsOnDuplicateId() throws Exception {
	    String uniqueId = "Id-" + System.currentTimeMillis();
	    Account account = new Account(uniqueId);
	    this.accountsService.createAccount(account);

	    try {
	      this.accountsService.createAccount(account);
	      fail("Should have failed when adding duplicate account");
	    } catch (DuplicateAccountIdException ex) {
	      assertThat(ex.getMessage()).isEqualTo("Account id " + uniqueId + " already exists!");
	    }

	  }

	  @Test
	  public void testTransferAmount() {
		  Account account1=new Account("account 1");
		  account1.setBalance(BigDecimal.valueOf(50));
		  Account account2=new Account("account 2");
		  account2.setBalance(BigDecimal.valueOf(100));
		  
		  this.accountsService.createAccount(account1);
		  this.accountsService.createAccount(account2);
		  
		  assertThat(this.accountsService.transferAmount(account1.getAccountId(), account2.getAccountId(),BigDecimal.valueOf(25))).isTrue();
		  assertThat(account1.getBalance()).isEqualTo(BigDecimal.valueOf(25));
		  
		  assertThat(account2.getBalance()).isEqualTo(BigDecimal.valueOf(125));
	  }
	  @Test
	  public void test_TransferAmount_invalidAmount() {
		  Account account1=new Account("account 3");
		  account1.setBalance(BigDecimal.valueOf(50));
		  Account account2=new Account("account 4");
		  account2.setBalance(BigDecimal.valueOf(100));
		  this.accountsService.createAccount(account1);

		  this.accountsService.createAccount(account2);
		  
		  assertThat(this.accountsService.transferAmount(account1.getAccountId(), account2.getAccountId(), BigDecimal.valueOf(-25))).isFalse();
		  assertThat(account1.getBalance()).isEqualTo(BigDecimal.valueOf(50));
		  
	  }
	  @Test
	  public void test_TransferAmount_insfficientBalance() {
		  Account account1=new Account("account 5");
		  account1.setBalance(BigDecimal.valueOf(50));
		  Account account2=new Account("account 6");
		  account2.setBalance(BigDecimal.valueOf(100));
		  this.accountsService.createAccount(account1);

		  this.accountsService.createAccount(account2);
		  
		  assertThat(this.accountsService.transferAmount(account1.getAccountId(), account2.getAccountId(), BigDecimal.valueOf(60))).isFalse();
		  assertThat(account1.getBalance()).isEqualTo(BigDecimal.valueOf(50));
		  
	  }


	@Test
	void contextLoads() {
	}

}
