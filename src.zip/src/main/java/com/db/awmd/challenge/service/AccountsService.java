package com.db.awmd.challenge.service;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.repositry.AccountsRepository;

import lombok.Getter;

@Service
public class AccountsService {

  @Getter
  private final AccountsRepository accountsRepository;


@Autowired
  public AccountsService(AccountsRepository accountsRepository) {
    this.accountsRepository = accountsRepository;
  }

  public void createAccount(Account account) {
    this.accountsRepository.createAccount(account);
  }

  public Account getAccount(String accountId) {
    return this.accountsRepository.getAccount(accountId);
  }
  
  //need to remove code bcoz of lombok not working 
  public AccountsRepository getAccountsRepository() {
	return accountsRepository;
}

  
  public boolean transferAmount(String accountId1, String accountId2, BigDecimal amount) {
	  if(amount.compareTo(BigDecimal.ZERO)<=0) {
		  return false;
	  }
	  Account account1;
	  Account account2;
	  account1=this.getAccount(accountId1);
	  account2=this.getAccount(accountId2);
	  
	  Account lock1=null;
	  Account lock2=null;
	  if(accountId1.compareTo(accountId2)>0) {
		  lock1=account1;
		  lock2=account2;
		  }
	  else {
		  lock1=account2;
		  lock2=account1;
		  
	  }
	  
	  synchronized(lock1) {
		  if(amount.compareTo(account1.getBalance())>0) {
			  return false;
		  }

		  synchronized(lock2) {
			account1.setBalance(account1.getBalance().subtract(amount));	 
			account2.setBalance(account2.getBalance().add(amount));	  

	  }}
	  return true;
  
}}
